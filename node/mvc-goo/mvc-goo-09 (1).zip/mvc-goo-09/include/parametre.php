<?php
/**
 * Définition des accès à la base de données
 * @date 08/03/2021
 */
define('SERVEUR', 'localhost');
define('UTILISATEUR', 'root');
define('MOTDEPASSE', '');
define('BASEDEDONNEES', 'gourmandise_sarl');
