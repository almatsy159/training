<?php
require_once ('parametre.php');
require_once ('modele.php');
require_once ('autoloader.php');
require_once ('libs/Smarty.class.php');
